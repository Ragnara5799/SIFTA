#!/bin/bash
OUTPUTPATH="/home/ragnara/Schreibtisch/AppAnalyse/Graph/graphDaten"
SIFTAPATH="/home/ragnara/Schreibtisch/AppAnalyse/SIFTA_OLD"
MAXLENGTH="50"

python $SIFTAPATH/sifta/scripts/centrality.py $OUTPUTPATH $MAXLENGTH


