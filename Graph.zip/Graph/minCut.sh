#!/bin/bash
# Pfad in dem die Ergebnisse gespeichert werden
OUTPUTPATH="/home/ragnara/Schreibtisch/AppAnalyse/Graph/MinCut"
# Pfad des SIFTA Ordners.
SIFTAPATH="/home/ragnara/Schreibtisch/AppAnalyse/SIFTA_OLD"
# Ziel des Partiellen MinCut 
PARTIALMINCUTLIMIT="0.6"

 time python $SIFTAPATH/sifta/scripts/min-cut.py $PARTIALMINCUTLIMIT $OUTPUTPATH


