#!/bin/bash
# Pfad indem die ergebnisse gespeichert werden
OUTPUTPATH="/home/ragnara/Schreibtisch/AppAnalyse/SIFTA_OLD/Graph/ClusterFiles"
# Pfad des Sifta-Ordners
SIFTAPATH="/home/ragnara/Schreibtisch/AppAnalyse/SIFTA_OLD"
FSUPPSETCOMPUTED="0"
if [ -f "$OUTPUTPATH/firstSupportSetSameEdge.pkl" ];
then
    FSUPPSETCOMPUTED="1"
    echo "first Supportset already computed"
else
    FSUPPSETCOMPUTED="0"
    echo "compute first Supportset"
fi
# Das Supportlimit für den FrequentSetMining Teil. Da hier der Algorithmus nur bis Schritt 2 läuft kann das Limit deutlich geringer gesetzt werden.
SUPPLIMIT="1000"
# Der Suffix für die Dateien der Ergebnisse
FILENAME="graph_1000"
# Das Limit für das Clustering. Heißt alle Kanten mit dieser Größer oder kleiner werden aus dem Graph gelöscht.
EDGELIMIT="28.0"

python $SIFTAPATH/sifta/scripts/frequentSetMining.py "transformSetMiningIntoGraph" $OUTPUTPATH $SUPPLIMIT $FSUPPSETCOMPUTED $FILENAME

python $SIFTAPATH/sifta/scripts/cluster.py $OUTPUTPATH/$FILENAME $OUTPUTPATH $EDGELIMIT $FILENAME

